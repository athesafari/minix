export const seedTweets = [
  {
    id: '1985956427744301489',
    username: 'athe',
    text: 'Raisecall',
    created_at: '2025-11-05T06:24:44.000Z',
    comments: []
  }
]
